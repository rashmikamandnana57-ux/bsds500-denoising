# 轻量卷积网络在灰度图像高斯去噪中的残差学习研究

本实验用 BSDS500 比较直接预测干净图像与预测噪声残差的五层 CNN。配对训练采用 10 轮和 30 轮两个预算，并加入经过验证集选参的高斯平滑、局部维纳滤波。测试使用四档噪声和每档三份固定噪声实现。

## 安装与准备数据

使用 Python 3.12 和 CPU。在仓库根目录运行下列命令，建议使用独立虚拟环境。

```text
python -m pip install --index-url https://download.pytorch.org/whl/cpu torch==2.14.0+cpu
python -m pip install -r requirements.txt
python experiment.py data --data data
```

数据命令默认下载[伯克利官方归档](https://www2.eecs.berkeley.edu/Research/Projects/CS/vision/grouping/resources.html)，并提取 200/100/200 张训练/验证/测试 JPEG。可用 `--archive 路径` 指定已下载的官方归档，或指定[伯克利 BIDS 镜像固定提交](https://github.com/BIDS/BSDS500/tree/a04b7c6c3a9f0ace74bf205c72a43d32e1c72722)的 ZIP。实验用的 500 张镜像 JPEG 已与官方归档逐字节核对，记录见 `dataset.json`。

## 加载交付权重并核对

```text
python expanded.py calibrate --data data --output reproduced/filter_validation.json
python expanded.py --threads 2 --workers 4 evaluate --data data --checkpoints . --parameters reproduced/filter_validation.json --output reproduced/per_image.csv
python expanded.py compare per_image.csv reproduced/per_image.csv
python expanded.py audit --original-logs budget10/logs --replay-logs budget30/logs --original-scores original_per_image.csv --expanded-scores reproduced/per_image.csv --output reproduced/audit.json
python expanded_analysis.py --data data --results . --output reproduced/figures
```

`compare` 检查全部 36,000 条记录的身份、分组、PSNR 和 SSIM。跨 CPU 或依赖环境的浮点舍入可能造成轻微差异。同一实验环境在 `budget10/environment.json` 和 `budget30/environment.json` 中记录。

## 从头训练

```text
python experiment.py --threads 6 train --epochs 10 --data data --output retrained/budget10
python experiment.py --threads 6 train --epochs 30 --data data --output retrained/budget30
python expanded.py calibrate --data data --output retrained/filter_validation.json
python expanded.py --threads 2 --workers 4 evaluate --data data --checkpoints retrained --parameters retrained/filter_validation.json --output retrained/per_image.csv
python expanded.py audit --original-logs retrained/budget10/logs --replay-logs retrained/budget30/logs --original-scores original_per_image.csv --expanded-scores retrained/per_image.csv --output retrained/audit.json
python expanded_analysis.py --data data --results retrained --output retrained/figures
```

训练采用 17、42、73 三个种子。同一种子内两种网络共用初始权重、图块、样本顺序和噪声。噪声以 8 位灰度级为单位，按 `σ/255` 加入 [0,1] 图像并截断。按固定验证图块的平均 PSNR 选预算内最佳权重。传统滤波也仅在相同验证图块上选参。测试时噪声档位为 15、25、50、70，`draw=0` 复用初版噪声，另外两次使用独立固定种子。

## 文件说明

| 文件 | 内容 |
| --- | --- |
| `budget10/` 与 `budget30/` | 两种方法各三个种子的最佳权重、逐轮训练日志及运行环境 |
| `per_image.csv` | 200 张测试图 × 4 档 × 3 份噪声 × 15 个方法与种子组合 |
| `original_per_image.csv` | 初版 4,200 条测试指标，便于核对重叠条件 |
| `filter_validation.json` | 参数网格、每个参数的验证分数及最终参数 |
| `summary.json` | 论文汇总、配对区间、分组结果、权重选择和样例 |
| `audit.json` | 前 10 轮训练记录及与初版重叠的测试指标核验 |
| `dataset.json` 与 `SHA256SUMS.txt` | 数据清单、归档来源和包内文件 SHA-256 |

在每张图上先平均噪声实现与训练种子，再在图像上取均值。差值区间以图像为单位做 10,000 次成对自助抽样，保留同一图像上的方法配对关系。原图从数据来源下载，代码包包含复现所需脚本和数值记录。

## 文献

- [DnCNN](https://doi.org/10.1109/TIP.2017.2662206)
- [BSDS500](https://doi.org/10.1109/TPAMI.2010.161)
- [SSIM](https://doi.org/10.1109/TIP.2003.819861)
- [SciPy 局部维纳滤波](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.wiener.html)

"""Train and evaluate paired lightweight CNNs on the official BSDS500 split."""

import argparse
import csv
import hashlib
import json
import math
import platform
import re
import tarfile
import time
import urllib.request
from importlib.metadata import version
from pathlib import Path
from zipfile import ZipFile

import numpy as np
from PIL import Image
import torch
from skimage.metrics import structural_similarity
from torch import nn


SOURCE = (
    "https://www2.eecs.berkeley.edu/Research/Projects/CS/vision/grouping/"
    "BSR/BSR_bsds500.tgz"
)
MIRROR = "https://github.com/BIDS/BSDS500"
COUNTS = {"train": 200, "val": 100, "test": 200}
SEEDS = (17, 42, 73)
SIGMAS = (15, 25, 50)
METHODS = ("direct", "residual")
EPOCHS = 10
PATCHES_PER_IMAGE = 16
PATCH = 32
BATCH = 64
LR = 0.001
VAL_CROP = 128


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def prepare_data(root, archive):
    root.mkdir(parents=True, exist_ok=True)
    if archive is None:
        archive = root / "BSR_bsds500.tgz"
    if not archive.exists():
        temporary = archive.with_suffix(".download")
        urllib.request.urlretrieve(SOURCE, temporary)
        temporary.replace(archive)
    pattern = re.compile(r"(?:^|/)BSDS500/data/images/(train|val|test)/(\d+\.jpg)$")
    extracted = {split: set() for split in COUNTS}
    mirror_commit = None

    def extract(names, read):
        for name_in_archive in names:
            match = pattern.search(name_in_archive)
            if not match:
                continue
            split, name = match.groups()
            if name in extracted[split]:
                raise ValueError(f"Duplicate image in archive: {split}/{name}")
            extracted[split].add(name)
            destination = root / split / name
            destination.parent.mkdir(exist_ok=True)
            destination.write_bytes(read(name_in_archive))

    if archive.suffix.lower() == ".zip":
        with ZipFile(archive) as bundle:
            comment = bundle.comment.decode("ascii", errors="ignore")
            if re.fullmatch(r"[0-9a-f]{40}", comment):
                mirror_commit = comment
            extract([name for name in bundle.namelist() if not name.endswith("/")], bundle.read)
    else:
        with tarfile.open(archive, "r:gz") as bundle:
            def read_tar(name):
                with bundle.extractfile(name) as source:
                    return source.read()
            extract([m.name for m in bundle if m.isfile()], read_tar)
    counts = {split: len(names) for split, names in extracted.items()}
    if counts != COUNTS or len(set.union(*extracted.values())) != sum(COUNTS.values()):
        raise ValueError(f"Unexpected image manifest or overlapping splits: {counts}")
    manifest = {
        "source": SOURCE,
        "used_archive": archive.name,
        "mirror_repository": MIRROR if archive.suffix.lower() == ".zip" else None,
        "mirror_commit": mirror_commit,
        "archive_sha256": sha256(archive),
        "counts": counts,
        "image_ids": {split: sorted(names) for split, names in extracted.items()},
    }
    write_json(root / "dataset.json", manifest)
    print(f"Official split {counts}; archive SHA256 {manifest['archive_sha256']}", flush=True)


def load_images(root, split):
    manifest = json.loads((root / "dataset.json").read_text(encoding="utf-8"))
    names = manifest["image_ids"][split]
    if len(names) != COUNTS[split]:
        raise ValueError(f"Unexpected {split} image count")
    images = {}
    for name in names:
        with Image.open(root / split / name) as image:
            images[Path(name).stem] = np.asarray(image.convert("L"), dtype=np.float32) / 255
    return images


class Denoiser(nn.Sequential):
    def __init__(self):
        layers = []
        widths = (1, 16, 16, 16, 16, 1)
        for i, (inputs, outputs) in enumerate(zip(widths, widths[1:])):
            layers.append(nn.Conv2d(inputs, outputs, 3, padding=1))
            if i < 4:
                layers.append(nn.ReLU())
        super().__init__(*layers)


def initialize(seed):
    torch.manual_seed(seed)
    direct = Denoiser()
    residual = Denoiser()
    residual.load_state_dict(direct.state_dict())
    return {method: model.to(memory_format=torch.channels_last)
            for method, model in zip(METHODS, (direct, residual))}


def checkpoint_path(folder, method, seed):
    return folder / "weights" / f"{method}_seed{seed}.pt"


def add_noise(clean, sigma, rng):
    standard = rng.standard_normal(clean.shape, dtype=np.float32)
    return np.clip(clean + standard * (np.asarray(sigma, dtype=np.float32) / 255), 0, 1)


def center_crop(image, size):
    height, width = image.shape
    row, col = (height - size) // 2, (width - size) // 2
    return image[row:row + size, col:col + size]


def fixed_noise(clean, image_id, sigma, split):
    rng = np.random.default_rng(np.random.SeedSequence([20261110, split, int(image_id), sigma]))
    return add_noise(clean, sigma, rng)


def training_data(images, seed, epoch):
    rng = np.random.default_rng(np.random.SeedSequence([seed, epoch, 2026]))
    samples = np.empty((len(images) * PATCHES_PER_IMAGE, PATCH, PATCH), np.float32)
    i = 0
    for image in images.values():
        height, width = image.shape
        rows = rng.integers(height - PATCH + 1, size=PATCHES_PER_IMAGE)
        cols = rng.integers(width - PATCH + 1, size=PATCHES_PER_IMAGE)
        for row, col in zip(rows, cols):
            samples[i] = image[row:row + PATCH, col:col + PATCH]
            i += 1
    samples = samples[rng.permutation(len(samples))]
    sigma = rng.uniform(5, 55, size=(len(samples), 1, 1))
    return samples, add_noise(samples, sigma, rng)


def as_tensor(array):
    return torch.from_numpy(np.ascontiguousarray(array[:, None])).contiguous(
        memory_format=torch.channels_last
    )


def restore(model, method, noisy):
    prediction = model(noisy)
    return (prediction if method == "direct" else noisy - prediction).clamp(0, 1)


@torch.inference_mode()
def validation_score(model, method, clean, noisy):
    scores = []
    model.eval()
    for target, observed in zip(clean.split(8), noisy.split(8)):
        prediction = restore(model, method, observed)
        mse = (prediction - target).square().mean((1, 2, 3))
        scores.extend((-10 * torch.log10(mse.clamp_min(1e-12))).tolist())
    return float(np.mean(scores))


def write_rows(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def train(root, output, seeds, epochs=EPOCHS):
    train_images = load_images(root, "train")
    val_images = load_images(root, "val")
    val_crops = {key: center_crop(image, VAL_CROP) for key, image in val_images.items()}
    val_clean = as_tensor(np.stack(list(val_crops.values())))
    val_noisy = as_tensor(np.stack([
        fixed_noise(image, key, 25, 1) for key, image in val_crops.items()
    ]))
    (output / "weights").mkdir(parents=True, exist_ok=True)
    (output / "logs").mkdir(exist_ok=True)
    write_json(output / "environment.json", {
        "python": platform.python_version(), "platform": platform.platform(),
        "device": "cpu", "threads": torch.get_num_threads(),
        "packages": {p: version(p) for p in ("torch", "numpy", "Pillow", "scikit-image", "matplotlib")},
    })
    for seed in seeds:
        rows = []
        models = initialize(seed)
        optimizers = {name: torch.optim.Adam(model.parameters(), lr=LR)
                      for name, model in models.items()}
        best = dict.fromkeys(METHODS, -math.inf)
        for epoch in range(1, epochs + 1):
            started = time.perf_counter()
            clean, noisy = training_data(train_images, seed, epoch)
            clean, noisy = as_tensor(clean), as_tensor(noisy)
            losses = dict.fromkeys(METHODS, 0.0)
            for model in models.values():
                model.train()
            for target, observed in zip(clean.split(BATCH), noisy.split(BATCH)):
                for method, model in models.items():
                    optimizer = optimizers[method]
                    optimizer.zero_grad(set_to_none=True)
                    label = target if method == "direct" else observed - target
                    loss = nn.functional.mse_loss(model(observed), label)
                    loss.backward()
                    optimizer.step()
                    losses[method] += loss.item()
            scores = {method: validation_score(model, method, val_clean, val_noisy)
                      for method, model in models.items()}
            elapsed = round(time.perf_counter() - started, 3)
            for method, model in models.items():
                improved = scores[method] > best[method]
                if improved:
                    best[method] = scores[method]
                    torch.save(model.state_dict(), checkpoint_path(output, method, seed))
                rows.append({
                    "seed": seed, "epoch": epoch, "method": method,
                    "train_mse": losses[method] / (len(clean) // BATCH),
                    "val_psnr": scores[method], "updated_checkpoint": int(improved),
                    "paired_epoch_seconds": elapsed,
                })
            write_rows(output / "logs" / f"train_seed{seed}.csv", rows)
            print(f"seed={seed} epoch={epoch:2}/{epochs} direct={scores['direct']:.4f} "
                  f"residual={scores['residual']:.4f} paired_seconds={elapsed:.2f}", flush=True)


def load_model(folder, method, seed):
    model = Denoiser().to(memory_format=torch.channels_last)
    state = torch.load(checkpoint_path(folder, method, seed), map_location="cpu", weights_only=True)
    model.load_state_dict(state)
    return model.eval()


def predict_image(model, method, observed):
    with torch.inference_mode():
        return restore(model, method, as_tensor(observed[None]))[0, 0].numpy()


def metrics(clean, estimate):
    mse = np.mean(np.square(estimate - clean, dtype=np.float64))
    psnr = -10 * math.log10(max(mse, 1e-12))
    ssim = structural_similarity(
        clean, estimate, data_range=1.0, gaussian_weights=True,
        sigma=1.5, use_sample_covariance=False,
    )
    return {"psnr": psnr, "ssim": float(ssim)}


def texture_score(image):
    return float((np.abs(np.diff(image, axis=0)).mean() +
                  np.abs(np.diff(image, axis=1)).mean()) / 2)


def texture_groups(images):
    scores = {key: texture_score(value) for key, value in images.items()}
    order = sorted(images, key=lambda key: (scores[key], int(key)))
    groups = {str(key): label for label, ids in zip(
        ("low", "mid", "high"), np.array_split(order, 3)) for key in ids}
    return scores, groups


def evaluate(root, checkpoints, output):
    test_images = load_images(root, "test")
    scores, groups = texture_groups(test_images)
    models = {(method, seed): load_model(checkpoints, method, seed)
              for method in METHODS for seed in SEEDS}
    rows = []
    for sigma in SIGMAS:
        for i, (key, clean) in enumerate(test_images.items(), start=1):
            noisy = fixed_noise(clean, key, sigma, 2)
            context = {"image_id": key, "sigma": sigma, "texture": scores[key], "group": groups[key]}
            rows.append({**context, "method": "noisy", "seed": 0, **metrics(clean, noisy)})
            for (method, seed), model in models.items():
                prediction = predict_image(model, method, noisy)
                rows.append({**context, "method": method, "seed": seed, **metrics(clean, prediction)})
            if i % 50 == 0:
                print(f"test sigma={sigma} images={i}/{len(test_images)}", flush=True)
    output.parent.mkdir(parents=True, exist_ok=True)
    write_rows(output, rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--threads", type=int, default=4)
    commands = parser.add_subparsers(dest="command", required=True)
    data = commands.add_parser("data")
    data.add_argument("--data", type=Path, required=True)
    data.add_argument("--archive", type=Path)
    train_command = commands.add_parser("train")
    train_command.add_argument("--data", type=Path, required=True)
    train_command.add_argument("--output", type=Path, required=True)
    train_command.add_argument("--seeds", type=int, nargs="+", choices=SEEDS, default=SEEDS)
    train_command.add_argument("--epochs", type=int, choices=(EPOCHS, 30), default=EPOCHS)
    test = commands.add_parser("evaluate")
    test.add_argument("--data", type=Path, required=True)
    test.add_argument("--checkpoints", type=Path, required=True)
    test.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    torch.set_num_threads(args.threads)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    if args.command == "data":
        prepare_data(args.data, args.archive)
    elif args.command == "train":
        train(args.data, args.output, args.seeds, args.epochs)
    else:
        evaluate(args.data, args.checkpoints, args.output)


if __name__ == "__main__":
    main()

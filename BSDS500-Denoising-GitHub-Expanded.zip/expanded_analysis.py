"""Aggregate paired image metrics and reproduce figures for the expanded paper."""

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import numpy as np
import torch

from analyze import detail_box
from expanded import (
    BUDGETS, DRAWS, FILTER_GRIDS, LEVELS, MODEL_ORDER, filter_image, read_json, read_rows,
    test_noise,
)
from experiment import METHODS, SEEDS, load_images, load_model, predict_image, write_json


METRICS = ("psnr", "ssim")
COLORS = {
    "direct10": "#6D9BCC", "direct30": "#235788",
    "residual10": "#E49D71", "residual30": "#A9502B",
    "noisy": "#78838B", "gaussian": "#597861", "wiener": "#6E6291",
}
LABELS = {
    "noisy": "Noisy input", "gaussian": "Gaussian", "wiener": "Wiener",
    "direct10": "Direct 10", "residual10": "Residual 10",
    "direct30": "Direct 30", "residual30": "Residual 30",
}
GROUPS = ("low", "mid", "high")


def method_seeds(method):
    return SEEDS if method.startswith(("direct", "residual")) else (0,)


def summarize_effect(values, bootstrap):
    low, high = np.quantile(values[bootstrap].mean(axis=1), [0.025, 0.975])
    return {"mean": float(values.mean()), "ci95": [float(low), float(high)],
            "wins": int(np.sum(values > 0)), "ties": int(np.sum(values == 0)),
            "p10_p50_p90": np.quantile(values, [.1, .5, .9]).tolist()}


def aggregate(rows):
    index = {}
    images = sorted({row["image_id"] for row in rows}, key=int)
    groups = {}
    for row in rows:
        image_id = row["image_id"]
        group = row["group"]
        if groups.setdefault(image_id, group) != group or group not in GROUPS:
            raise ValueError(f"Inconsistent texture group for {image_id}")
        key = (int(row["sigma"]), image_id, int(row["draw"]), row["method"], int(row["seed"]))
        if key in index:
            raise ValueError(f"Duplicate observation {key}")
        index[key] = tuple(float(row[m]) for m in METRICS)
    if len(images) != 200 or len(index) != 36000:
        raise ValueError("Expected 200 images and 36,000 unique observations")
    bootstrap = np.random.default_rng(2026).integers(0, len(images), (10000, len(images)))
    summary = {}
    cases = []
    for sigma in LEVELS:
        raw = {
            method: np.asarray([[[index[sigma, image_id, draw, method, seed]
                                  for seed in method_seeds(method)] for draw in DRAWS]
                                for image_id in images])
            for method in MODEL_ORDER
        }
        if any(not np.isfinite(value).all() for value in raw.values()):
            raise ValueError(f"Non-finite metric for sigma={sigma}")
        per_image = {method: values.mean(axis=(1, 2)) for method, values in raw.items()}
        gap10 = per_image["residual10"] - per_image["direct10"]
        gap30 = per_image["residual30"] - per_image["direct30"]
        comparisons = {
            "gap10": gap10, "gap30": gap30, "gap_change": gap30 - gap10,
            "direct_gain": per_image["direct30"] - per_image["direct10"],
            "residual_gain": per_image["residual30"] - per_image["residual10"],
            "residual_vs_gaussian": per_image["residual30"] - per_image["gaussian"],
            "residual_vs_wiener": per_image["residual30"] - per_image["wiener"],
        }
        subgroups = {}
        for group in GROUPS:
            mask = [groups[image_id] == group for image_id in images]
            subgroup = gap30[mask]
            subgroups[group] = {"n": int(sum(mask)), **{
                metric: {"mean": float(subgroup[:, i].mean()),
                         "wins": int((subgroup[:, i] > 0).sum())}
                for i, metric in enumerate(METRICS)
            }}
        summary[sigma] = {
            "means": {method: dict(zip(METRICS, values.mean(axis=0).tolist()))
                      for method, values in per_image.items()},
            "paired": {contrast: {metric: summarize_effect(values[:, i], bootstrap)
                                  for i, metric in enumerate(METRICS)}
                       for contrast, values in comparisons.items()},
            "seed_gaps": {f"budget{budget}": dict(zip(METRICS, (
                raw[f"residual{budget}"] - raw[f"direct{budget}"]
            ).mean(axis=(0, 1)).T.tolist())) for budget in BUDGETS},
            "texture": subgroups,
        }
        if sigma in (25, 70):
            if sigma == 25:
                selected = np.argsort(gap30[:, 0], kind="stable")[len(images) // 2]
                draw, seed = 0, 42
                role = "typical"
            else:
                selected = np.argmin(gap30[:, 0])
                deltas = raw["residual30"][selected, :, :, 0] - raw["direct30"][selected, :, :, 0]
                draw_index, seed_index = np.unravel_index(np.argmin(deltas), deltas.shape)
                draw, seed = DRAWS[draw_index], SEEDS[seed_index]
                role = "min_gap"
            key = images[selected]
            case = {"role": role, "image_id": key, "sigma": sigma, "draw": draw, "seed": seed,
                    "group": groups[key], "mean_gap": float(gap30[selected, 0]), "metrics": {}}
            for method in ("noisy", "gaussian", "wiener", "direct30", "residual30"):
                m_seed = seed if method in ("direct30", "residual30") else 0
                case["metrics"][method] = dict(zip(METRICS, index[sigma, key, draw, method, m_seed]))
            cases.append(case)
    return summary, cases


def save(fig, path):
    fig.savefig(path, dpi=280, facecolor="white")
    plt.close(fig)


def pipeline(path):
    fig, ax = plt.subplots(figsize=(6.25, 2.3))
    ax.set(xlim=(0, 1), ylim=(0, 1))
    ax.axis("off")
    def box(x, y, w, h, label, color):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=.012,rounding_size=.02",
                                    facecolor=color, edgecolor="#596A79", linewidth=.8))
        ax.text(x + w / 2, y + h / 2, label, ha="center", va="center", fontsize=8.6)
    def arrow(start, end):
        ax.annotate("", xy=end, xytext=start,
                    arrowprops={"arrowstyle": "->", "color": "#4A5967", "lw": 1.1})
    box(.02, .38, .19, .20, "Shared input\nnoisy image y", "#EEF1F4")
    box(.33, .64, .26, .20, "Direct CNN\nlearn the clean image", "#E8F0F9")
    box(.33, .11, .26, .20, "Residual CNN\nlearn the noise residual", "#FAECE4")
    box(.72, .64, .25, .20, "Clip the prediction\nto [0, 1]", "#E8F0F9")
    box(.72, .11, .25, .20, "Subtract from y\nthen clip to [0, 1]", "#FAECE4")
    arrow((.23, .51), (.31, .74))
    arrow((.23, .45), (.31, .21))
    arrow((.61, .74), (.70, .74))
    arrow((.61, .21), (.70, .21))
    fig.subplots_adjust(left=.01, right=.99, top=.97, bottom=.04)
    save(fig, path)


def filter_plot(calibration, path):
    fig, axes = plt.subplots(1, 2, figsize=(6.3, 2.65), layout="constrained")
    for axis, method, xlabel in zip(axes, FILTER_GRIDS, ("Gaussian scale (pixels)", "Wiener window width")):
        entries = calibration["grid"][method]
        x = [e["parameter"] for e in entries]
        y = [e["val_psnr"] for e in entries]
        axis.plot(x, y, "-o", ms=4, lw=1.5, color=COLORS[method])
        best = x.index(calibration["chosen"][method])
        axis.scatter([x[best]], [y[best]], s=66, facecolors="none", edgecolors="#242C35", linewidths=1.1)
        axis.set(xlabel=xlabel, ylabel="Validation PSNR (dB)", xticks=x)
        axis.grid(axis="y", alpha=.22)
    save(fig, path)


def training_plot(results, path):
    curves = {method: [] for method in METHODS}
    checkpoints = {}
    for budget in BUDGETS:
        checkpoints[budget] = {}
        for seed in SEEDS:
            rows = read_rows(results / f"budget{budget}" / "logs" / f"train_seed{seed}.csv")
            for method in METHODS:
                scores = [float(row["val_psnr"]) for row in rows if row["method"] == method]
                if len(scores) != budget:
                    raise ValueError(f"Incomplete training record: {budget}, {method}, {seed}")
                checkpoints[budget].setdefault(method, {})[seed] = {
                    "epoch": int(np.argmax(scores)) + 1, "psnr": max(scores),
                }
                if budget == 30:
                    curves[method].append(scores)
    training = {"selected": checkpoints}
    fig, axes = plt.subplots(2, 1, figsize=(6.3, 3.82), layout="constrained",
                             gridspec_kw={"height_ratios": [1.75, 1]})
    epochs = np.arange(1, 31)
    for method in METHODS:
        scores = np.asarray(curves[method])
        mean = scores.mean(axis=0)
        axes[0].plot(epochs, mean, lw=1.75, color=COLORS[f"{method}30"], label=method.capitalize())
        axes[0].fill_between(epochs, scores.min(axis=0), scores.max(axis=0),
                             color=COLORS[f"{method}30"], alpha=.16, linewidth=0)
    gaps = np.asarray(curves["residual"]) - np.asarray(curves["direct"])
    for seed, gap in zip(SEEDS, gaps):
        axes[1].plot(epochs, gap, linewidth=1.05, label=f"Seed {seed}")
    axes[1].axhline(0, color="#414D59", lw=.8)
    for axis in axes:
        axis.axvline(10, color="#79808A", ls="--", lw=1)
        axis.set_xticks([1, 5, 10, 15, 20, 25, 30])
        axis.grid(axis="y", alpha=.18)
        axis.legend(frameon=False, fontsize=8, ncols=3)
    axes[0].set_ylabel("Validation PSNR (dB)")
    axes[1].set(xlabel="Epoch", ylabel="Paired gap (dB)")
    for epoch in (1, 10, 30):
        training[f"gap_epoch{epoch}"] = float(gaps[:, epoch - 1].mean())
    save(fig, path)
    return training


def effect_plot(summary, path):
    fig, axes = plt.subplots(1, 2, figsize=(6.35, 2.95), layout="constrained")
    positions = np.arange(len(LEVELS))
    for axis, metric, title in zip(axes, METRICS, ("PSNR gap (dB)", "SSIM gap")):
        for key, shift, label, color in (
                ("gap10", -.13, "Budget 10", "#526F9F"), ("gap30", .13, "Budget 30", "#B05A36")):
            entries = [summary[s]["paired"][key][metric] for s in LEVELS]
            means = np.asarray([e["mean"] for e in entries])
            low, high = np.asarray([e["ci95"] for e in entries]).T
            axis.errorbar(positions + shift, means, yerr=[means - low, high - means], fmt="o",
                          ms=4, elinewidth=1.05, capsize=3, color=color, label=label)
        axis.axhline(0, color="#293746", lw=.8)
        axis.set(xlabel="Noise level", ylabel=title, xticks=positions, xticklabels=LEVELS)
        axis.grid(axis="y", alpha=.20)
        axis.legend(frameon=False, fontsize=7.5)
    save(fig, path)


def noise_plot(summary, path):
    fig, axes = plt.subplots(1, 2, figsize=(6.3, 3.25), layout="constrained")
    for axis, metric, title in zip(axes, METRICS, ("Test PSNR (dB)", "Test SSIM")):
        for method, symbol in zip(("noisy", "gaussian", "wiener", "direct30", "residual30"),
                                  ("x", "^", "s", "o", "d")):
            series = [summary[s]["means"][method][metric] for s in LEVELS]
            axis.plot(LEVELS, series, "-" + symbol, ms=4, lw=1.4, label=LABELS[method],
                      color=COLORS[method], alpha=.88)
        axis.axvline(55, ls="--", color="#9BA2AC", lw=.8)
        axis.set(xlabel="Noise level", ylabel=title, xticks=LEVELS)
        axis.grid(axis="y", alpha=.20)
    axes[1].legend(loc="best", frameon=False, fontsize=7.4)
    save(fig, path)


def group_plot(summary, path):
    fig, axis = plt.subplots(figsize=(6.3, 2.65), layout="constrained")
    positions = np.arange(len(LEVELS))
    for i, (group, color) in enumerate(zip(GROUPS, ("#527E9C", "#919EAF", "#BB764D"))):
        values = [summary[s]["texture"][group]["psnr"]["mean"] for s in LEVELS]
        axis.bar(positions + (i - 1) * .23, values, width=.21, color=color,
                 label=group.capitalize())
    axis.axhline(0, color="#293746", lw=.8)
    axis.set(xlabel="Noise level", ylabel="Residual 30 minus direct 30 (dB)",
             xticks=positions, xticklabels=LEVELS)
    axis.legend(frameon=False, ncols=3, loc="upper center", bbox_to_anchor=(.5, 1.18))
    axis.grid(axis="y", alpha=.20)
    save(fig, path)


def example_plots(data, results, calibration, cases, output):
    images = load_images(data, "test")
    for case in cases:
        key, sigma, draw, seed = (case[k] for k in ("image_id", "sigma", "draw", "seed"))
        clean = images[key]
        noisy = test_noise(clean, key, sigma, draw)
        panels = {"clean": clean, "noisy": noisy}
        for name, parameter in calibration["chosen"].items():
            panels[name] = filter_image(name, noisy, parameter)
        for method in METHODS:
            model = load_model(results / "budget30", method, seed)
            panels[f"{method}30"] = predict_image(model, method, noisy)
        row, col, size = detail_box(clean, 80)
        case["crop"] = [row, col, size]
        fig, axes = plt.subplots(2, 3, figsize=(6.4, 2.78))
        for axis, (name, image) in zip(axes.ravel(), panels.items()):
            axis.imshow(image[row:row + size, col:col + size], vmin=0, vmax=1,
                        cmap="gray", interpolation="nearest")
            label = "Clean" if name == "clean" else LABELS[name]
            axis.set_title(label, fontsize=8, pad=2.8)
            if name != "clean":
                values = case["metrics"][name]
                axis.set_xlabel(f"{values['psnr']:.2f} dB  /  {values['ssim']:.3f}",
                                fontsize=7, labelpad=1)
            axis.set(xticks=[], yticks=[])
            for edge in axis.spines.values():
                edge.set_visible(False)
        fig.subplots_adjust(left=.04, right=.96, top=.91, bottom=.11, wspace=.15, hspace=.40)
        save(fig, output / f"case_{case['role']}.png")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ("data", "results", "output"):
        parser.add_argument(f"--{key}", required=True, type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5,
                         "axes.spines.top": False, "axes.spines.right": False})
    summary, cases = aggregate(read_rows(args.results / "per_image.csv"))
    calibration = read_json(args.results / "filter_validation.json")
    pipeline(args.output / "pipeline.png")
    filter_plot(calibration, args.output / "filters.png")
    training = training_plot(args.results, args.output / "training.png")
    effect_plot(summary, args.output / "paired.png")
    noise_plot(summary, args.output / "noise.png")
    group_plot(summary, args.output / "texture.png")
    example_plots(args.data, args.results, calibration, cases, args.output)
    write_json(args.output / "summary.json", {"results": summary, "training": training,
               "cases": cases, "calibration": calibration, "audit": read_json(args.results / "audit.json")})


if __name__ == "__main__":
    main()

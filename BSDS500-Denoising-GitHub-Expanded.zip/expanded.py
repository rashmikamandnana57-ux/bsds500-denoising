"""Calibrate classical filters and evaluate the expanded BSDS500 experiment."""

import argparse
import csv
import json
import math
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter
from scipy.signal import wiener
import torch

from experiment import (
    METHODS, SEEDS, SIGMAS, VAL_CROP, add_noise, center_crop, fixed_noise,
    load_images, load_model, metrics, predict_image, texture_groups, write_json, write_rows,
)


BUDGETS = (10, 30)
LEVELS = (*SIGMAS, 70)
DRAWS = (0, 1, 2)
FILTER_GRIDS = {"gaussian": (0.4, 0.6, 0.8, 1.0, 1.2, 1.6, 2.0),
                "wiener": (3, 5, 7, 9)}
MODEL_ORDER = ("noisy", *FILTER_GRIDS, "direct10", "residual10", "direct30", "residual30")


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def read_rows(path):
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def filter_image(method, image, parameter):
    if method == "gaussian":
        result = gaussian_filter(image, sigma=parameter, mode="reflect", truncate=4.0)
    elif np.ptp(image) == 0:
        result = image
    else:
        with np.errstate(divide="ignore", invalid="ignore"):
            result = wiener(image, mysize=int(parameter), noise=None)
    if not np.isfinite(result).all():
        raise ValueError(f"Invalid values from {method} filter")
    return np.clip(result, 0, 1).astype(np.float32, copy=False)


def calibrate(data, output):
    clean = {key: center_crop(image, VAL_CROP)
             for key, image in load_images(data, "val").items()}
    noisy = {key: fixed_noise(image, key, 25, 1) for key, image in clean.items()}
    scores = {}
    for method, grid in FILTER_GRIDS.items():
        scores[method] = []
        for parameter in grid:
            mse = [
                np.square(filter_image(method, noisy[key], parameter) - image,
                          dtype=np.float64).mean()
                for key, image in clean.items()
            ]
            average = float(np.mean(-10 * np.log10(np.maximum(mse, 1e-12))))
            scores[method].append({"parameter": parameter, "val_psnr": average})
    chosen = {method: max(entries, key=lambda x: x["val_psnr"])["parameter"]
              for method, entries in scores.items()}
    output.parent.mkdir(parents=True, exist_ok=True)
    write_json(output, {"split": "val", "image_count": 100, "crop": VAL_CROP, "sigma": 25,
                        "chosen": chosen, "grid": scores})
    print(f"Validation filters selected: {chosen}", flush=True)


def test_noise(clean, image_id, sigma, draw):
    if draw == 0:
        return fixed_noise(clean, image_id, sigma, 2)
    seed = np.random.SeedSequence([20261110, 2, int(image_id), sigma, draw])
    return add_noise(clean, sigma, np.random.default_rng(seed))


def load_models(root):
    return {(budget, method, seed): load_model(root / f"budget{budget}", method, seed)
            for budget in BUDGETS for method in METHODS for seed in SEEDS}


def evaluate(data, checkpoints, parameters, output, workers):
    images = load_images(data, "test")
    texture, groups = texture_groups(images)
    models = load_models(checkpoints)
    chosen = read_json(parameters)["chosen"]

    def score_image(sigma, key):
        clean = images[key]
        rows = []
        for draw in DRAWS:
            noisy = test_noise(clean, key, sigma, draw)
            prefix = {"image_id": key, "sigma": sigma, "draw": draw,
                      "texture": texture[key], "group": groups[key]}
            rows.append({**prefix, "method": "noisy", "seed": 0, **metrics(clean, noisy)})
            for method, parameter in chosen.items():
                restored = filter_image(method, noisy, parameter)
                rows.append({**prefix, "method": method, "seed": 0, **metrics(clean, restored)})
            for (budget, method, seed), model in models.items():
                restored = predict_image(model, method, noisy)
                rows.append({**prefix, "method": f"{method}{budget}", "seed": seed,
                             **metrics(clean, restored)})
        return rows

    all_rows = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        for sigma in LEVELS:
            for i, rows in enumerate(pool.map(lambda key: score_image(sigma, key), images), 1):
                all_rows.extend(rows)
                if i % 50 == 0:
                    print(f"sigma={sigma}: {i}/200 images × {len(DRAWS)} noise draws", flush=True)
    output.parent.mkdir(parents=True, exist_ok=True)
    write_rows(output, all_rows)
    print(f"Recorded {len(all_rows):,} image metrics", flush=True)


def audit(original_logs, replay_logs, original_scores, expanded_scores, output):
    training_max_abs = {"train_mse": 0.0, "val_psnr": 0.0}
    training_rows = 0
    for seed in SEEDS:
        filename = f"train_seed{seed}.csv"
        original = read_rows(original_logs / filename)
        replay = [r for r in read_rows(replay_logs / filename) if int(r["epoch"]) <= 10]
        if len(original) != 20 or len(replay) != 20:
            raise ValueError(f"Incomplete training record: {seed}")
        for first, second in zip(original, replay):
            for key in ("seed", "epoch", "method", "updated_checkpoint"):
                if first[key] != second[key]:
                    raise ValueError(f"Replay metadata mismatch: {seed}, {key}")
            for key, tol in (("train_mse", 1e-6), ("val_psnr", 1e-5)):
                error = abs(float(first[key]) - float(second[key]))
                if error > tol:
                    raise ValueError(f"Training replay mismatch: {seed}, {key}, {error}")
                training_max_abs[key] = max(training_max_abs[key], error)
            training_rows += 1
    result = {"training_rows_compared": training_rows, "training_max_abs": training_max_abs}
    if expanded_scores is not None:
        def keys(row, method):
            return int(row["sigma"]), row["image_id"], method, int(row["seed"])

        original = {keys(r, r["method"]): r for r in read_rows(original_scores)}
        subset = {keys(r, r["method"].removesuffix("10")): r for r in read_rows(expanded_scores)
                  if int(r["sigma"]) in SIGMAS and r["draw"] == "0"
                  and r["method"] in ("noisy", "direct10", "residual10")}
        if original.keys() != subset.keys() or len(subset) != 4200:
            raise ValueError("Legacy evaluation record IDs differ")
        max_abs = {"psnr": 0.0, "ssim": 0.0}
        for key, first in original.items():
            second = subset[key]
            for metric, tol in (("psnr", 1e-4), ("ssim", 1e-6)):
                error = abs(float(first[metric]) - float(second[metric]))
                if error > tol:
                    raise ValueError(f"Legacy metric mismatch: {key}, {metric}, {error}")
                max_abs[metric] = max(max_abs[metric], error)
        result.update({"legacy_rows_compared": len(subset), "legacy_max_abs": max_abs})
    output.parent.mkdir(parents=True, exist_ok=True)
    write_json(output, result)
    print(json.dumps(result, indent=2), flush=True)


def compare_reproduction(first, second):
    baseline, replay = read_rows(first), read_rows(second)
    if len(baseline) != 36000 or len(replay) != len(baseline):
        raise ValueError("Expected 36,000 rows in each run")
    max_abs = {"psnr": 0.0, "ssim": 0.0}
    for original, repeat in zip(baseline, replay):
        for key in ("image_id", "sigma", "draw", "method", "seed", "group", "texture"):
            if original[key] != repeat[key]:
                raise ValueError(f"Run key mismatch in {key}: {original} vs. {repeat}")
        for metric, limit in (("psnr", 1e-4), ("ssim", 1e-6)):
            left, right = float(original[metric]), float(repeat[metric])
            error = abs(left - right)
            if not math.isfinite(error) or error > limit:
                raise ValueError(f"Reproduced {metric} mismatch: {original} vs. {repeat}")
            max_abs[metric] = max(max_abs[metric], error)
    print(f"All 36,000 rows reproduced. Maximum absolute differences: {max_abs}", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--workers", type=int, default=4)
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("calibrate", "evaluate", "audit", "compare"):
        command = commands.add_parser(name)
        if name in ("calibrate", "evaluate"):
            command.add_argument("--data", required=True, type=Path)
        if name in ("calibrate", "evaluate", "audit"):
            command.add_argument("--output", required=True, type=Path)
        if name == "evaluate":
            command.add_argument("--checkpoints", required=True, type=Path)
            command.add_argument("--parameters", required=True, type=Path)
        if name == "audit":
            command.add_argument("--original-logs", required=True, type=Path)
            command.add_argument("--replay-logs", required=True, type=Path)
            command.add_argument("--original-scores", type=Path)
            command.add_argument("--expanded-scores", type=Path)
        if name == "compare":
            command.add_argument("baseline", type=Path)
            command.add_argument("replay", type=Path)
    args = parser.parse_args()
    if args.command == "calibrate":
        calibrate(args.data, args.output)
    elif args.command == "evaluate":
        torch.set_num_threads(args.threads)
        torch.set_num_interop_threads(1)
        torch.use_deterministic_algorithms(True)
        evaluate(args.data, args.checkpoints, args.parameters, args.output, args.workers)
    elif args.command == "audit":
        audit(args.original_logs, args.replay_logs, args.original_scores,
              args.expanded_scores, args.output)
    else:
        compare_reproduction(args.baseline, args.replay)


if __name__ == "__main__":
    main()

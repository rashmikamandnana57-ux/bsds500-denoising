"""Build paired comparisons and figures from the recorded experiment."""

import argparse
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

from experiment import (
    METHODS, SEEDS, SIGMAS, fixed_noise, load_images, load_model, metrics,
    predict_image, texture_score, write_json,
)


METRICS = ("psnr", "ssim")
LABELS = {"noisy": "Noisy input", "direct": "Direct CNN", "residual": "Residual CNN"}
COLORS = {"noisy": "#687684", "direct": "#2D62A8", "residual": "#B65A29"}


def read_rows(path):
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def paired_summary(rows):
    images = sorted({row["image_id"] for row in rows}, key=int)
    data = {(int(r["sigma"]), r["image_id"], r["method"], int(r["seed"])): r for r in rows}
    if len(images) != 200 or len(data) != len(rows) or len(data) != 4200:
        raise ValueError("Expected 4200 unique records across 200 held-out images")
    groups = {key: data[25, key, "noisy", 0]["group"] for key in images}
    scores = {key: float(data[25, key, "noisy", 0]["texture"]) for key in images}
    group_order = {group: sorted([key for key in images if groups[key] == group],
                                 key=lambda key: (scores[key], int(key)))
                   for group in ("low", "mid", "high")}
    rng = np.random.default_rng(2026)
    boot = rng.integers(0, len(images), size=(10000, len(images)))
    comparison = {}
    grouping = {}
    cases = {}
    for sigma in SIGMAS:
        comparison[sigma] = {}
        grouping[sigma] = {}
        for metric in METRICS:
            def values(method, seeds):
                return np.asarray([[float(data[sigma, key, method, seed][metric])
                                    for seed in seeds] for key in images])
            per_seed = {method: values(method, SEEDS) for method in METHODS}
            noisy = values("noisy", (0,)).ravel()
            direct = per_seed["direct"].mean(axis=1)
            residual = per_seed["residual"].mean(axis=1)
            delta = residual - direct
            ci = np.quantile(delta[boot].mean(axis=1), [0.025, 0.975])
            comparison[sigma][metric] = {
                "noisy": float(noisy.mean()), "direct": float(direct.mean()),
                "residual": float(residual.mean()), "delta": float(delta.mean()),
                "ci95": ci.tolist(), "wins": int(np.sum(delta > 0)),
                "ties": int(np.sum(delta == 0)),
                "seed_deltas": (per_seed["residual"] - per_seed["direct"]).mean(axis=0).tolist(),
            }
            for group, members in group_order.items():
                mask = np.asarray([key in members for key in images])
                grouping[sigma].setdefault(group, {"n": len(members)})[metric] = {
                    "direct": float(direct[mask].mean()),
                    "residual": float(residual[mask].mean()),
                    "delta": float(delta[mask].mean()),
                }
            if sigma == 25 and metric == "psnr":
                worst = int(np.argmin(delta))
                cases["worst"] = images[worst]
                cases["worst_delta"] = float(delta[worst])
                cases["worst_group"] = groups[images[worst]]
                cases["worst_seed"] = SEEDS[int(np.argmin(
                    per_seed["residual"][worst] - per_seed["direct"][worst]
                ))]
    for group in ("low", "high"):
        ids = group_order[group]
        cases[group] = ids[len(ids) // 2]
    texture = {group: [scores[ids[0]], scores[ids[-1]]] for group, ids in group_order.items()}
    return comparison, grouping, cases, texture


def plot_training(log_dir, destination):
    history = {}
    checkpoints = {}
    for seed in SEEDS:
        rows = read_rows(log_dir / f"train_seed{seed}.csv")
        for method in METHODS:
            scores = [float(row["val_psnr"]) for row in rows if row["method"] == method]
            if len(scores) != 10:
                raise ValueError(f"Incomplete history: {seed} {method}")
            history[method, seed] = scores
            checkpoints.setdefault(method, {})[seed] = {
                "epoch": int(np.argmax(scores)) + 1, "val_psnr": max(scores),
            }
    fig, ax = plt.subplots(figsize=(6.7, 2.8), layout="constrained")
    for method in METHODS:
        curves = np.array([history[method, seed] for seed in SEEDS])
        epochs = np.arange(1, 11)
        ax.fill_between(epochs, curves.min(axis=0), curves.max(axis=0),
                        color=COLORS[method], alpha=0.13, linewidth=0)
        ax.plot(epochs, curves.mean(axis=0), "-o", label=LABELS[method],
                color=COLORS[method], lw=1.8, ms=3.5)
    ax.set(xlabel="Epoch", ylabel="Validation PSNR (dB)", xticks=np.arange(1, 11))
    ax.grid(axis="y", alpha=0.22)
    ax.legend(loc="lower right", frameon=False)
    fig.savefig(destination, dpi=260)
    plt.close(fig)
    return checkpoints


def plot_groups(grouping, destination):
    fig, ax = plt.subplots(figsize=(6.7, 2.7), layout="constrained")
    x = np.arange(len(SIGMAS))
    for i, (group, color) in enumerate(zip(("low", "mid", "high"),
                                         ("#4C7197", "#8D9DAA", "#C37A4F"))):
        data = [grouping[sigma][group]["psnr"]["delta"] for sigma in SIGMAS]
        ax.bar(x + (i - 1) * .24, data, width=.22, color=color,
               label=f"{group.capitalize()} texture")
    ax.axhline(0, color="#273442", lw=.9)
    ax.set(xlabel="Noise level (sigma, 8-bit scale)", ylabel="Residual - direct (dB)",
           xticks=x, xticklabels=SIGMAS)
    ax.grid(axis="y", alpha=.22)
    ax.legend(frameon=False, ncols=3, loc="upper center", bbox_to_anchor=(.5, 1.18))
    fig.savefig(destination, dpi=260)
    plt.close(fig)


def detail_box(image, size=80):
    height, width = image.shape
    candidates = [(r, c) for r in range(0, height - size + 1, size // 2)
                  for c in range(0, width - size + 1, size // 2)]
    row, col = max(candidates, key=lambda rc: texture_score(
        image[rc[0]:rc[0] + size, rc[1]:rc[1] + size]))
    return row, col, size


def plot_examples(data_root, weights, cases, destination):
    sigma = 25
    images = load_images(data_root, "test")
    models = {(method, seed): load_model(weights, method, seed)
              for method in METHODS for seed in {42, cases["worst_seed"]}}
    fig, axes = plt.subplots(3, 4, figsize=(6.7, 5.55))
    titles = ("Clean reference", "Noisy input", "Direct CNN", "Residual CNN")
    notes = {}
    for i, (role, label) in enumerate((("low", "Low"), ("high", "High"), ("worst", "Min delta"))):
        image_id = cases[role]
        seed = cases["worst_seed"] if role == "worst" else 42
        clean = images[image_id]
        noisy = fixed_noise(clean, image_id, sigma, 2)
        views = [clean, noisy, *(predict_image(models[m, seed], m, noisy) for m in METHODS)]
        row, col, size = detail_box(clean)
        full_psnr = [None, *(metrics(clean, value)["psnr"] for value in views[1:])]
        notes[role] = {"id": image_id, "seed": seed, "crop": [row, col, size], "psnr": full_psnr}
        for j, (axis, view) in enumerate(zip(axes[i], views)):
            axis.imshow(view[row:row + size, col:col + size],
                        cmap="gray", vmin=0, vmax=1, interpolation="nearest")
            axis.set(xticks=[], yticks=[])
            for edge in axis.spines.values():
                edge.set_visible(False)
            if i == 0:
                axis.set_title(titles[j], fontsize=8)
            if j == 0:
                axis.set_ylabel(f"{label}\n{image_id}", rotation=0, fontsize=7.5,
                                ha="right", va="center", labelpad=4)
            else:
                axis.set_xlabel(f"{full_psnr[j]:.2f} dB", fontsize=7.5, labelpad=1)
    fig.subplots_adjust(left=.12, right=.99, top=.94, bottom=.04, wspace=.06, hspace=.27)
    fig.savefig(destination, dpi=270)
    plt.close(fig)
    return notes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    torch.set_num_threads(4)
    torch.set_num_interop_threads(1)
    args.output.mkdir(parents=True, exist_ok=True)
    rows = read_rows(args.results / "per_image.csv")
    scores, grouping, cases, texture = paired_summary(rows)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9,
                         "axes.spines.top": False, "axes.spines.right": False})
    checkpoint = plot_training(args.results / "logs", args.output / "training.png")
    plot_groups(grouping, args.output / "texture.png")
    examples = plot_examples(args.data, args.results, cases, args.output / "examples.png")
    write_json(args.output / "summary.json", {
        "metrics": scores, "texture_groups": grouping, "texture_ranges": texture,
        "case_selection": cases, "example_panels": examples, "checkpoints": checkpoint,
    })


if __name__ == "__main__":
    main()
